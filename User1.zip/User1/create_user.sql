CREATE DATABASE wp_project DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci;

GRANT ALL ON web2012.* TO 'oys'@'localhost' IDENTIFIED BY 'jajt1';

use wp_project;


CREATE TABLE users (
	id INT AUTO_INCREMENT PRIMARY KEY, 
	userid VARCHAR(100) NOT NULL UNIQUE,
	name VARCHAR(100),
	pwd VARCHAR(255) NOT NULL, 
	email VARCHAR(100) UNIQUE,
	country VARCHAR(100),
	gender CHAR(1) NOT NULL,
	phone VARCHAR(11)
);
CREATE TABLE calendar (
	cname VARCHAR(20) PRIMARY KEY,
	cdate date,
	cshare varchar(10) not null,
	ccontext varchar(10) not null,
	caaniversary varchar(10) not null,
	calram varchar(10) not null,
	clatelyupload varchar(10) not null
);
CREATE TABLE friend(
	fid varchar(12) primary key,
	fname varchar(10) not null,
	femail varchar(15) not null,
	fphone varchar(13) not null
);